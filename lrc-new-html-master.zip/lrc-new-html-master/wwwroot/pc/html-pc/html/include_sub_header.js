$(function(){


    var header = `
	<!--header 컴포넌트-->
	<header class="header">

	<!--해더상단-->
	<div class="header-top">
		<div class="inner">
			<div class="header-basic">
				<a href="#container" class="skip_nav">본문 바로가기</a>
				<h1><a href="#none"><img src="../../../resources-pc/images/common/logo-header.png" alt="LOTTE rental"/></a></h1>
				<ul class="top-menu">
					<li><a href="">심<b>夜</b>신차<span class="new">new</span></a></li>
					<li><a href="">특가모아보기</a></li>
					<li><a href="">이벤트</a></li>
					<li><a href="">고객후기</a></li>
				</ul>
				<ul class="extra-menu">
					<li class="name">홍길동님</li>
					<li class="business"><a href="#none">개인사업자 등록</a></li>
					<li class="layer-login-open" data-layer="layer-login"><a href="#none">로그인</a></li>
					<li><a href="#none">로그아웃</a></li>
					<li><a href="javascript:fnHpCallLpointScreen('JOIN_MEMBER')" class="lPointAutoChange">회원가입</a></li>							
					<li class="mypage"><a href="">마이페이지</a></li>							
					<li class="customer">
						<a href="/customer/faq.do?mnCd=MNCD06001">고객센터</a>
						<div class="link">
							<ul>
								<li><a href="/customer/faq.do?mnCd=MNCD06001">FAQ</a></li>
								<li><a href="/customer/notice.do?mnCd=MNCD06008">공지사항</a></li>
								<li><a href="/customer/consultation.do?mnCd=MNCD06002">일반 문의</a></li>
								<li><a href="/customer/saleconsultation.do?mnCd=MNCD06003">전문상담신청</a></li>
							</ul>
						</div>
					</li>
				</ul>
			</div>
			<div class="header-menu-links">
				<ul>
					<li>
						<a href="#">
							<div class="link-in"><i class="icon menu-link01"></i><span>견적</span></div>
						</a>
					</li>
					<li>
						<a href="#">
							<div class="link-in"><i class="icon menu-link02"></i><span>상담신청</span></div>
						</a>
					</li>
					<li>
						<a href="#">
							<div class="link-in"><i class="icon menu-link03"></i><span>보관함</span></div>
						</a>
					</li>
				</ul>
			</div>
			<div class="header-menu-btn">
				<button type="button"><i class="icon menu"></i></button>
			</div>
		</div>
	</div>
	<!--//해더상단-->
	<!--해더네비-->
	<nav class="header-nav">
		<div class="inner">
			<ul>
				<li>
					<a href="#">신차장 다이렉트란?</a>
					<ul class="submenu">
						<li class="depth2"><a href="">신차장 다이렉트 소개</a></li>
						<li class="depth2"><a href="">개인사업자 이용 안내</a></li>
						<li class="depth2"><a href="">신차장기렌터카 안내</a></li>
					</ul>
				</li>
				<li>
					<a href="#">CAR뮤니티</a>
					<ul class="submenu">
						<li class="depth2"><a href="">이 차 어때?</a></li>
						<li class="depth2"><a href="">고객후기</a></li>
						<li class="depth2"><a href="">신차장 매거진</a></li>
					</ul>
				</li>
				<li>
					<a href="#">견적/심사/계약</a>
					<ul class="submenu">
						<li class="depth2"><a href="">견적</a></li>
						<li class="depth2"><a href="">심사</a></li>
						<li class="depth2"><a href="">계약</a></li>
					</ul>
				</li>
				<li>
					<a href="#">기획전</a>
					<ul class="submenu">
						<li class="depth2"><a href="">기획전</a></li>
					</ul>
				</li>
				<li>
					<a href="#">뭉치면 특가</a>
					<ul class="submenu">
						<li class="depth2"><a href="">신차장 추천</a></li>
						<li class="depth2"><a href="">인기상품</a></li>
						<li class="depth2"><a href="">계약 BEST</a></li>
						<li class="depth2"><a href="">사전예약 / 공동구매</a></li>
					</ul>
				</li>
				<li>
					<a href="#">혜택 및 이벤트</a>
					<ul class="submenu">
						<li class="depth2"><a href="">진행중인 이벤트</a></li>
						<li class="depth2"><a href="">지난 이벤트</a></li>
						<li class="depth2"><a href="">제휴카드</a></li>
						<li class="depth2"><a href="">당첨자 발표</a></li>
					</ul>
				</li>
			</ul>
		</div>
	</nav>
	<!--//해더네비-->
	</header>
	<!--//header 컴포넌트-->


	<div class="path-wrap">
        <div class="inner">
            <strong>견적</strong>
            <ul>
                <li>
                    <a href="">HOME</a>
                </li>
                <li>
                    <a href="">견적</a>
                </li>
                <li>
                    <b>차량선택</b>
                </li>
            </ul>
        </div>
	</div>
	
    `;


    $(".header").html(header);
    $(".header .header").unwrap();

});