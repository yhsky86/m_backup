$(function(){


    var footer = `
	<!--footer 컴포넌트-->
	<footer class="footer">
		<div class="footer-top-wrap">
			<div class="inner">
				<div class="footer-link">
					<ul>
						<li>
							<a href="#" onclick="members.goWithNoAuth('https://www.lotterentacar.net/kor/main/index.do', 'Y')">롯데렌터카</a>					
						</li>
						<li>
							<a href="#" onclick="members.goWithNoAuth('https://www.lotteautoauction.net/hp/pub/cmm/viewMain.do', 'Y')">오토옥션</a>					
						</li>
						<li>
							<a href="https://www.lotte-autolease.net" target="_blank">오토리스</a>
						</li>
						<li>
							<a href="#" onclick="members.goWithNoAuth('https://manager.lotterentacar.net/main.do', 'Y')">신차장 멤버십</a>					
						</li>
						<li>
							<a href="http://www.greencar.co.kr" target="_blank">그린카</a>
						</li>
					</ul>
					<div class="toggle-footer">
						<button type="button" class="btn toggle-footer-btn" data-on="true" data-sort="none" data-target="toggle-footer-list">롯데 제휴사</button>
						<div class="toggle-footer-list">
							<div class="overflow-y">
								<div class="toggle-footer-list-col">
									<strong>그룹</strong>
									<ul>
										<li><a href="http://www.lotte.co.kr" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데그룹');">롯데그룹</a></li>
										<li><a href="http://job.lotte.co.kr" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데채용센터');">롯데채용센터</a></li>
										<li><a href="https://www.lpoint.com" target="_blank" onclick="ga('send','event','footer-link-partners','click','L.POINT');">L.POINT</a></li>
										<li><a href="https://www.lpay.com" target="_blank" onclick="ga('send','event','footer-link-partners','click','L.pay');">L.pay</a></li>
									</ul>
								</div>
								<div class="toggle-footer-list-col">
									<strong>식품</strong>
									<ul>
										<li>
											<a href="http://lotteconf.co.kr" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데제과');">롯데제과</a>
											<ul>
												<li class="el"><a href="http://www.natuur.co.kr" target="_blank" onclick="ga('send','event','footer-link-partners','click','나뚜루');">나뚜루</a></li>
												<li class="el"><a href="http://www.lotteconf.co.kr" target="_blank" onclick="ga('send','event','footer-link-partners','click','빼빼로');">빼빼로</a></li>
												<li class="el"><a href="http://www.lottehealth1.com" target="_blank" onclick="ga('send','event','footer-link-partners','click','헬스원');">헬스원</a></li>
											</ul>
										</li>
										<li><a href="https://company.lottechilsung.co.kr" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데칠성음료');">롯데칠성음료</a></li>
										<li><a href="https://mall.lottechilsung.co.kr" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데칠성몰');">롯데칠성몰</a></li>
										<li>
											<a href="http://www.lotteria.com" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데리아');">롯데리아</a>
											<ul>
												<li class="el"><a href="http://www.lotteriamall.com" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데리아몰');">롯데리아몰</a></li>
											</ul>
										</li>
										<li>
											<a href="http://www.angelinus.com" target="_blank" onclick="ga('send','event','footer-link-partners','click','엔젤리너스');">엔젤리너스</a>
											<ul>
												<li class="el"><a href="http://shop.angelinus.com" target="_blank" onclick="ga('send','event','footer-link-partners','click','엔젤리너스몰');">엔젤리너스몰</a></li>
											</ul></li>
										<li><a href="http://www.tgif.co.kr" target="_blank" onclick="ga('send','event','footer-link-partners','click','T.G.I.Fridays');">T.G.I.Friday's</a></li>
										<li><a href="http://www.krispykreme.co.kr" target="_blank" onclick="ga('send','event','footer-link-partners','click','크리스피크림도넛');">크리스피크림도넛</a></li>
										<li>
											<a href="http://www.lottefoods.co.kr" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데푸드');">롯데푸드</a>
											<ul>
											<li class="el"><a href="http://www.pasteur.co.kr" target="_blank" onclick="ga('send','event','footer-link-partners','click','파스퇴르');">파스퇴르</a></li>
											<li class="el"><a href="http://www.pasteurmall.com" target="_blank" onclick="ga('send','event','footer-link-partners','click','파스퇴르몰');">파스퇴르몰</a></li>
											<li class="el"><a href="http://www.pasteuri.com" target="_blank" onclick="ga('send','event','footer-link-partners','click','파스퇴르아이');">파스퇴르아이</a></li>
											<li class="el"><a href="http://www.lottefoods.co.kr/brand/chefood/chefood.asp" target="_blank" onclick="ga('send','event','footer-link-partners','click','쉐푸드');">쉐푸드</a></li>
											<li class="el"><a href="http://www.lottefoods.co.kr/brand/enNature/enNature.asp" target="_blank" onclick="ga('send','event','footer-link-partners','click','엔네이처');">엔네이처</a></li>
											<li class="el"><a href="http://www.lottefoods.co.kr/brand/lotteViennaSausage/lotteViennaSausage.asp" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데비엔나');">롯데비엔나</a></li>
											<li class="el"><a href="http://www.kisstick.co.kr" target="_blank" onclick="ga('send','event','footer-link-partners','click','키스틱');">키스틱</a></li>
											<li class="el"><a href="http://www.lottefoods.co.kr/brand/uiseongGarlicHam/uiseongGarlicHam.asp" target="_blank" onclick="ga('send','event','footer-link-partners','click','의성마늘햄');">의성마늘햄</a></li>
											</ul>
										</li>
										<li>
											<a href="http://www.lotteliquor.com" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데주류BG');">롯데주류BG</a>
											<ul>
											  	<li class="el"><a href="http://www.wine.co.kr" target="_blank" onclick="ga('send','event','footer-link-partners','click','WINE');">WINE</a></li>
											</ul>
										</li>
										<li><a href="http://www.asahibeerk.com" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데아사히주류');">롯데아사히주류</a></li>
										<li><a href="http://www.lotteliquor.com" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데칠성주류');">롯데칠성주류</a></li>
										<li><a href="https://www.lottelmsc.com" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데유통사업본부');">롯데유통사업본부</a></li>
										<li><a href="https://www.lotternd.com" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데중앙연구소');">롯데중앙연구소</a></li>
									</ul>
								</div>
								<div class="toggle-footer-list-col">
									<strong>유통</strong>
									<ul>
										<li>
											<a href="https://www.lotteshopping.com" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데백화점');">롯데백화점</a>
											<ul>
											<li class="el"><a href="https://display.ellotte.com/display-fo/shop" target="_blank" onclick="ga('send','event','footer-link-partners','click','엘롯데');">엘롯데</a></li>
											<li class="el"><a href="https://www.lotteshopping.com/branchShopGuide/floorGuideSub?cstr=0370" target="_blank" onclick="ga('send','event','footer-link-partners','click','영프라자');">영프라자</a></li>
											<li class="el"><a href="https://www.lotteshopping.com/branchShopGuide/floorGuideSub?cstr=0339" target="_blank" onclick="ga('send','event','footer-link-partners','click','프리미엄아울렛');">프리미엄아울렛</a></li>
											<li class="el"><a href="https://www.lotteshopping.com/branchShopGuide/floorGuideSub?cstr=0343" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데아울렛');">롯데아울렛</a></li>
											<li class="el"><a href="https://buying.lotteshopping.com" target="_blank" onclick="ga('send','event','footer-link-partners','click','상품본부');">상품본부</a></li>
											</ul>
										</li>
										<li><a href="https://www.lotteshopping.com" target="_blank" onclick="ga('send','event','footer-link-partners','click','에비뉴엘');">에비뉴엘</a></li>
										<li>
											<a href="http://www.lottemart.com" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데마트');">롯데마트</a>
											<ul>
											<li class="el"><a href="http://company.lottemart.com/bc/main.do" tatget="_blank" onclick="ga('send','event','footer-link-partners','click','롯데마트홍보');">롯데마트홍보</a></li>
											</ul>
										</li>
										<li>
											<a href="http://www.e-himart.co.kr" onclick="ga('send','event','footer-link-partners','click','롯데하이마트');">롯데하이마트</a>
											<ul>
											<li class="el"><a href="http://company.lottemart.com/vc/main.do" onclick="ga('send','event','footer-link-partners','click','롯데하이마트홍보');">롯데하이마트홍보</a></li>
											</ul>
										</li>
										<li><a href="http://toysrus.lottemart.com" target="_blank" onclick="ga('send','event','footer-link-partners','click','토이저러스');">토이저러스</a></li>
										<li><a href="http://www.lottesuper.co.kr" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데슈퍼');">롯데슈퍼</a></li>
										<li><a href="http://company.lottemart.com" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데빅마켓');">롯데빅마켓</a></li>
										<li><a href="http://www.lottecinema.co.kr" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데시네마');">롯데시네마</a></li>
										<li><a href="http://www.lotteimall.com" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데홈쇼핑');">롯데홈쇼핑</a></li>
										<li><a href="http://www.7-eleven.co.kr" target="_blank" onclick="ga('send','event','footer-link-partners','click','코리아세븐');">코리아세븐</a></li>
										<li><a href="https://store-kr.uniqlo.com" target="_blank" onclick="ga('send','event','footer-link-partners','click','유니클로');">유니클로</a></li>
										<li><a href="https://www.muji.com" target="_blank" onclick="ga('send','event','footer-link-partners','click','무인양품');">무인양품</a></li>
										<li><a href="http://www.lotteintl.co.kr" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데상사');">롯데상사</a></li>
										<li><a href="http://www.lotte.com" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데닷컴');">롯데닷컴</a></li>
										<li><a href="https://www.lohbs.co.kr" target="_blank" onclick="ga('send','event','footer-link-partners','click','H&amp;B(롭스)');">H&amp;B(롭스)</a></li>
										<li><a href="http://www.lottefitin.com" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데피트인');">롯데피트인</a></li>
									</ul>
								</div>
								<div class="toggle-footer-list-col">
									<strong>관광/서비스/금융</strong>
									<ul>
										<li><a href="http://www.charlottetheater.co.kr" target="_blank" onclick="ga('send','event','footer-link-partners','click','샤롯데씨어터');">샤롯데씨어터</a></li>
										<li><a href="https://www.lottehotel.com" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데호텔');">롯데호텔</a></li>
										<li><a href="https://kr.lottedfs.com" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데면세점');">롯데면세점</a></li>
										<li><a href="http://kor.lottedfs.com/kr" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데인터넷면세점');">롯데인터넷면세점</a></li>
										<li><a href="http://kor.lottedfs.com/kr" target="_blank" onclick="ga('send','event','footer-link-partners','click','부산롯데인터넷면세점');">부산롯데인터넷면세점</a></li>
										<li>
											<a href="http://www.lotteworld.com" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데월드');">롯데월드</a>
											<ul>
											<li class="el"><a href="http://www.lotteworld.com/waterpark/index.asp" target="_blank" onclick="ga('send','event','footer-link-partners','click','워터파크');">워터파크</a></li>
											<li class="el"><a href="http://www.lotteworld.com/aquarium/index.asp" target="_blank" onclick="ga('send','event','footer-link-partners','click','아쿠아리움');">아쿠아리움</a></li>
											</ul>
										</li>
										<li><a href="http://www.lotte.co.kr" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데물산');">롯데물산</a></li>
										<li><a href="https://www.lwt.co.kr/tower/ko/main/main.do" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데월드타워&amp;몰');">롯데월드타워&amp;몰</a></li>
										<li><a href="http://gimpoairport.lottemall.co.kr/handler/Main-Start" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데몰 김포공항점');">롯데몰 김포공항점</a></li>
										<li><a href="http://www.lottejtb.com" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데제이티비');">롯데제이티비</a></li>
										<li>
											<a href="http://www.lotteins.co.kr" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데손해보험');">롯데손해보험</a>
											<ul>
											<li class="el"><a href="http://www.lottehowmuch.com/" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데하우머치');">롯데하우머치</a></li>
											</ul>
										</li>
										<li><a href="https://www.lottecard.co.kr/app/LPMAIAA_V100.lc" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데카드');">롯데카드</a></li>
										<li><a href="http://www.lottecap.com" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데캐피탈');">롯데캐피탈</a></li>
										<li><a href="http://www.lotteacademy.co.kr" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데인재개발원');">롯데인재개발원</a></li>
										<li><a href="http://ez.lotteacademy.co.kr" target="_blank" onclick="ga('send','event','footer-link-partners','click','사이버 인재개발원');">사이버 인재개발원</a></li>
										<li><a href="http://www.ldcc.co.kr" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데정보통신');">롯데정보통신</a></li>
										<li><a href="http://www.giantsclub.com" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데자이언츠');">롯데자이언츠</a></li>
										<li><a href="http://www.skyhill.co.kr" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데스카이힐C.C');">롯데스카이힐C.C</a></li>
										<li><a href="https://www.lotteresortsokcho.com" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데리조트 속초');">롯데리조트 속초</a></li>
										<li><a href="http://www.lottebuyeoresort.com" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데리조트 부여');">롯데리조트 부여</a></li>
										<li><a href="http://www.lottejejuresort.com" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데리조트 제주');">롯데리조트 제주</a></li>
										<li><a href="https://www.daehong.com" target="_blank" onclick="ga('send','event','footer-link-partners','click','대홍기획');">대홍기획</a></li>
										<li><a href="https://www.cashbee.co.kr" target="_blank" onclick="ga('send','event','footer-link-partners','click','캐시비');">캐시비</a></li>
										<li><a href="https://www.mybi.co.kr" target="_blank" onclick="ga('send','event','footer-link-partners','click','마이비');">마이비</a></li>
										<li><a href="https://www.lotteglogis.com" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데로지스틱스');">롯데로지스틱스</a></li>
										<li><a href="https://www.lottefoundation.or.kr" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데재단');">롯데재단</a></li>
										<li>
											<a href="https://lotterental.com/" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데렌탈');">롯데렌탈</a>
											<ul>
											<li class="el"><a href="https://www.lotterentacar.net/" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데렌터카');">롯데렌터카</a></li>
											<li class="el"><a href="https://direct.lotterentacar.net/" target="_blank" onclick="ga('send','event','footer-link-partners','click','신차장 다이렉트');">신차장 다이렉트</a></li>
											<li class="el"><a href="https://manager.lotterentacar.net/" target="_blank" onclick="ga('send','event','footer-link-partners','click','신차장 멤버십');">신차장 멤버십</a></li>
											<li class="el"><a href="https://www.lotteautoauction.net/" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데오토옥션');">롯데오토옥션</a></li>
											<li class="el"><a href="https://www.lotte-autolease.net/" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데오토리스');">롯데오토리스</a></li>
											<li class="el"><a href="https://www.myomee.com/" target="_blank" onclick="ga('send','event','footer-link-partners','click','묘미');">묘미</a></li>
											<li class="el"><a href="https://www.greencar.co.kr/" target="_blank" onclick="ga('send','event','footer-link-partners','click','그린카');">그린카</a></li>
											</ul>
										</li>
										<li><a href="http://www.lotteconcerthall.com" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데콘서트홀');">롯데콘서트홀</a></li>
									</ul>
								</div>
								<div class="toggle-footer-list-col">
									<strong>화학&amp;건설&amp;제조</strong>
									<ul>
										<li>
											<a href="http://www.lottecon.co.kr" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데건설');">롯데건설</a>
											<ul>
											<li class="el"><a href="http://www.lottecastle.co.kr" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데캐슬');">롯데캐슬</a></li>
											</ul>
										</li>
										<li>
											<a href="http://www.fujifilm.co.kr" target="_blank" onclick="ga('send','event','footer-link-partners','click','한국후지필름');">한국후지필름</a>
											<ul>
											<li class="el"><a href="http://www.fujifilm.co.kr" target="_blank" onclick="ga('send','event','footer-link-partners','click','후지필름쇼핑몰');">후지필름쇼핑몰</a></li>
											</ul>
										</li>
										<li>
											<a href="https://www.lotteal.co.kr" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데알미늄');">롯데알미늄</a>
											<ul>
											<li class="el"><a href="http://www.lotteelife.co.kr" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데이라이프');">롯데이라이프</a></li>
											</ul>
										</li>
										<li><a href="https://www.lottechem.com" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데케미칼');">롯데케미칼</a></li>
										<li><a href="http://www.lottemcc.com" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데엠시시');">롯데엠시시</a></li>
										<li><a href="https://www.canon-bs.co.kr" target="_blank" onclick="ga('send','event','footer-link-partners','click','캐논코리아 비즈니스솔루션');">캐논코리아 비즈니스솔루션</a></li>
										<li><a href="http://www.lottelem.co.kr" target="_blank" onclick="ga('send','event','footer-link-partners','click','롯데기공');">롯데기공</a></li>							
									</ul>
								</div>
								
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<div class="inner">
			<div class="footer-logo">
				<img src="../../../resources-pc/images/common/logo-footer.png" alt="LOTTE rental"/>
			</div>
			<div class="footer-middle-wrap">
				<div class="information"> 
					<div class="sitemap">
						<ul>
							<li><a href="https://www.lotterentacar.net/kor/content/183/main.do?mnCd=FN0801" target="_blank">회사소개</a></li>
							<li><a href="https://www.lotterentacar.net/kor/footer/footerPolicyNew.do?mnCd=FN0901" class="txt_point" target="_blank">개인정보처리방침</a></li>
							<li><a href="https://www.lotterentacar.net/kor/content/190/main.do?mnCd=FN0902" class="txt_point" target="_blank">영상정보처리기기 운영관리방침</a></li>
							<li><a href="https://www.lotterentacar.net/kor/footer/footerTermsNew.do?mnCd=FN0903" target="_blank">이용약관</a></li>
							<!-- <li><a href="/kor/footer/companySinmungo.do?mnCd=FN080602" target="_blank" >사이버신문고</a></li> -->
							<!-- <li><a href="https://www.lotterentacar.net/kor/recruit/main.do?mnCd=FN0905" target="_blank">인재채용</a></li> -->
							<li><button type="button" class="layer-emailRejection-open" data-layer="layer-emailRejection">이메일주소무단수집거부</button></li>
							<!-- <li><a href="https://www.lotterentacar.net/kor/content/192/main.do?mnCd=FN0908" target="_blank">CONTACT US</a></li> -->
							<!-- <li><a href="/main/siteMap.do?mnCd=MNCD15">사이트맵</a></li>  -->
							<li><a href="#">찾아오시는 길</a></li>
						</ul>
					</div>

					<div class="site-infos">
						<div class="entrepreneur-info"> 
							<p>롯데렌탈㈜ <span class="nonecon">대표이사 김현수</span></p>
							<p>경기도 안양시 동안구 전파로 88 신원비젼타워 8층 <span>서울본사: 서울시 강남구 테헤란로 422 KT타워 6~9층</span></p>
							<p>사업자등록번호 214-87-79183 <a href="">통신판매업신고번호 : 제2010-경기안양-420호</a></p>
						</div>
						<div class="site-additional-info">
							<div class="sns-link">
								<ul>
									<li><a><i class="icon sns-b"></i></a></li>
									<li><a><i class="icon sns-n"></i></a></li>
									<li><a><i class="icon sns-f"></i></a></li>
									<li><a><i class="icon sns-in"></i></a></li>
									<li><a><i class="icon sns-tw"></i></a></li>
									<li><a><i class="icon sns-ka"></i></a></li>
								</ul>
							</div>
							<div class="app-down">
								<strong>앱 다운로드</strong>
								<ul>
									<li><a><i class="icon app-google"></i></a></li>
									<li><a><i class="icon app-store"></i></a></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
				<div class="service-center">
					<strong>고객센터</strong>
					<div class="cont">
						<span>1588-1230</span>
						<p>
							평일 08:30 ~ 20:00<br/>
							단, 사고처리 문의는 24시간 가능
						</p>
						<button type="btn">1:1 고객센터</button>
					</div>
				</div>
			</div>

			<div class="footer-bottom-wrap">
				<div class="award-top">
					<strong>롯데렌터카 수상내역</strong>
					<div class="slide-btn">
						<button class="pause"><i class="icon slide-pause"></i></button>
						<button class="play"><i class="icon slide-play"></i></button>
					</div>
				</div>
				

				<div class="award-wrap">
					
					<div class="swiper-container award-list">
						<div class="swiper-wrapper">
							
							<div class="swiper-slide">
								<div class="award-list-in">
									<div class="cover">
										<img src="../../../resources-pc/images/award-list01.png" alt="더미1"/>
									</div>
									<div class="text">
										<p>한국서비스대상 <br/>명예의 전당</p>
										<span>한국표준협회 <br/>2015년 명예의 전당 헌정</span>
									</div>
								</div>
							</div>
							<div class="swiper-slide">
								<div class="award-list-in">
									<div class="cover">
										<img src="../../../resources-pc/images/award-list02.png" alt="더미1"/>
									</div>
									<div class="text">
										<p>2018 국가고객만족도 <br/>렌터카부문1위(NCSI)</p>
										<span>한국생산성본부 4년<br/>연속 수상 (2015-2018)</span>
									</div>
								</div>
							</div>
							<div class="swiper-slide">
								<div class="award-list-in">
									<div class="cover">
										<img src="../../../resources-pc/images/award-list03.png" alt="더미1"/>
									</div>
									<div class="text">
										<p>2018 한국산업의 브랜드 <br/>파워 1위(K-BPI)</p>
										<span>한국능률협회컨설팅 16년<br/> 연속 수상 (2003-2018)</span>
									</div>
								</div>
							</div>
							<div class="swiper-slide">
								<div class="award-list-in">
									<div class="cover">
										<img src="../../../resources-pc/images/award-list04.png" alt="더미1"/>
									</div>
									<div class="text">
										<p>2018 대한민국 <br/>브랜드 스타</p>
										<span>브랜드스탁 12년 <br/>연속 수상 (2007-2018)</span>
									</div>
								</div>
							</div>
							<div class="swiper-slide">
								<div class="award-list-in">
									<div class="cover">
										<img src="../../../resources-pc/images/award-list05.png" alt="더미1"/>
									</div>
									<div class="text">
										<p>2018 국가브랜드 경쟁력<br/>지수 1위(NBCI)</p>
										<span>한국생산성본부 7년<br/> 연속 수상 (2012-2018)</span>
									</div>
								</div>
							</div>
						</div>
						<!-- Add Pagination -->
					</div>

				</div>

				<div class="copyright">copyright ⓒ 2017 LOTTE rental co.ltd.All Rights Reserved.</div>
			</div>
		</div>
	</footer>
	<!--//footer 컴포넌트-->

	`;
	

	var gotop = `
	<div id="btn_top">
		<button type="button" class="btn btn-goTop">탑으로</button>
	</div>
	`;

	var bgDim = `
	<!--bg-dimmed 컴포넌트-->
	<div class="bg-dimmed">딤(Dim)처리 배경</div>
	<!--//bg-dimmed 컴포넌트-->
	`;

    $(".footer").html(footer);
	$(".footer .footer").unwrap();
	
	$('body').append(gotop);
	$('body').append(bgDim);
});