$(function(){


    var header = `
    <!--header 컴포넌트-->
	<header class="partner-header">

		<div class="inner clfix">
            <div class="logo_wrap">
                <h1 class="logo"><a href="/partner/sm_202004/main.do" title="로고"><img src="../../../resources-mo/images/common/logo-header.png" alt="로고"></a></h1>
                <h1 class="logo_second"><a href="/partner/sm_202004/main.do" title="제휴사 로고"><img src="https://direct.lotterentacar.net/atch/getImage.do?atchFileId=ODM0000000000004520&amp;fileSn=0" alt="제휴사 로고"></a></h1>
            </div>
            <div class="gnb_view">
				<a href="/partner/sm_202004/mypage/mypage.do" title="마이페이지" class=""><img src="https://direct.lotterentacar.net/images/partner/common/admin_red.png" alt="마이페이지"></a>  
                <a href="javascript:;" title="메뉴" class="menu_on"><img src="https://direct.lotterentacar.net/images/partner/common/icon_menu.png" alt="메뉴버튼"></a>
            </div>
            <div class="gnbTotalBack" style="display: none;"></div>
			<div id="totalview" style="display: none;">
				<div class="gnb_top">
					<div class="gnb_bt close">
					<a href="javascript:;" title="닫기"><img src="https://direct.lotterentacar.net/images/partner/common/close.png" alt="닫기"></a>
					</div>
					<div class="gnb_toplist clfix">
					<div>
						<p><b>이동걸</b>님</p>
						<a href="javascript:;" data-sso-type="partnerlogout" title="로그아웃">로그아웃</a>
					</div>
					</div>
				</div> 
				<div class="openmenu">
					<ul class="allmenu">
						<li class="d1 active">
							<a href="javascript:;" title="신차장 다이렉트란">신차장 다이렉트란</a>
							<ul class="gnb_depth active">
								<li class="on"><a href="/partner/sm_202004/about/aboutOdm.do" title="신차장 다이렉트란">신차장 다이렉트란</a></li>							
							</ul>
						</li>
						<li class="d1 ">
							<a href="javascript:;" title="견적/심사/계약">견적/심사/계약</a>
							<ul class="gnb_depth ">
								<li><a onclick="javascript:goEstimateSM('sm_202004');" title="견적">견적</a></li>
								<li><a href="/partner/sm_202004/estimate/evalutionStep1.do" title="심사">심사</a></li>											
								<li><a href="/partner/sm_202004/estimate/contractStep1.do" title="계약">계약</a></li>				
							</ul>
						</li>
						<li class="d1 ">
							<a href="javascript:;" title="특가상품">특가상품</a>
							<ul class="gnb_depth ">
								<li><a href="/partner/sm_202004/special/specialList.do" title="특가상품">특가상품</a></li>											
							</ul>
						</li>
						<li class="d1 ">
							<a href="javascript:;" title="고객센터">고객센터</a>
							<ul class="gnb_depth ">
								<li><a href="/partner/sm_202004/customer/faq.do" title="FAQ">FAQ</a></li>											
								<li><a href="/partner/sm_202004/customer/notice.do" title="공지사항">공지사항</a></li>											
							</ul>
						</li>
					</ul>
				</div>
			</div>
        </div>
	</header>
	<!--//header 컴포넌트-->


    `;

    


    $('body').addClass('partner');
    $('header').html(header);
    $('header header').unwrap();

});