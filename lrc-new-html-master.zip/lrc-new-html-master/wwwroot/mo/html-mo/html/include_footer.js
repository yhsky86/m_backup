$(function(){


    var footer = `
    <!--footer 컴포넌트-->
	<footer class="footer">
		
	</footer>
	<!--//footer 컴포넌트-->

        <!--bg-dimmed 컴포넌트-->
        <div class="bg-dimmed">딤(Dim)처리 배경</div>
        <!--//bg-dimmed 컴포넌트-->

        <!--drawer 컴포넌트-->
	<div class="drawer">

		<div class="drawer-in">

			<!--로그인 전 :logout-state,  로그인 후:login-state-->
			<div class="drawer-top login-state">
				<div class="drawer-btns">
                    <div class="left">
                        <button type="button" class="btn btn-pannel"><i class="icon home">홈</i></button>
                        <button type="button" class="btn btn-pannel"><i class="icon alarm">알람</i></button>
                    </div>
                    <div class="right">
                        <button type="button" class="btn btn-pannel"><i class="icon setting">세팅</i></button>
                        <button type="button" class="btn btn-pannel btn-drawer-close" data-target="drawer" data-on="true" data-sort="none"><i class="icon pannelclose">패널 닫기</i></button>
                    </div>
                </div>
				<!--로그인 전-->
				<div class="logout-state-box">
                    <p>로그인 해주세요</p>
                    <button type="button" class="btn btn-simple black">로그인</button>
                </div>
				<!--//로그인 전-->

				<!--로그인 후-->
				<div class="login-state-box">
                    <div class="login-top">
                        <strong>홍길동님</strong>
                        <button type="button" class="btn-link">마이페이지</button>
                    </div>

					<div class="login-state-cont">
						<ul>
							<li>
								<div class="infos-inner">
									<a href="#">
										<strong>3</strong>
										<button type="button" class="btn-link">쿠폰함</button>
									</a>
								</div>
							</li>
							<li>
								<div class="infos-inner">
									<a href="#">
										<strong>3</strong>
										<button type="button" class="btn-link">견적보관함</button>
									</a>
								</div>
							</li>
							<li>
								<div class="infos-inner">
									<a href="#">
										<strong>1</strong>
										<button type="button" class="btn-link">관심 차량</button>
									</a>
								</div>
							</li>
						</ul>
					</div>
					
                </div>
				<!--로그인 후-->
			</div>

			<div class="drawer-cont">
				<div class="drawer-list">
					<h5><i class="icon pannel01" style="background-color:#CFF7EB;"></i><span>신차장 다이렉트란?</span></h5>
					<ul>
						<li><a href="#">신차장 다이렉트 소개</a></li>
						<li><a href="#">개인사업자 이용 안내</a></li>	
						<li><a href="#">신차장기렌터카 안내</a></li>
						<li></li>				
					</ul>
				</div>
				<div class="drawer-list">
					<h5><i class="icon pannel02" style="background-color:#FFE8E2;"></i><span>CAR뮤니티</span></h5>
					<ul>
						<li><a href="#">고민 상담소</a></li>
						<li><a href="#">고객 후기</a></li>	
						<li><a href="#">신차장 TV</a></li>	
						<li><a href="#">신차장 매거진</a></li>			
					</ul>
				</div>
				<div class="drawer-list">
					<h5><i class="icon pannel03" style="background-color:#E8E2FF;"></i><span>견적/심사/계약</span></h5>
					<ul>
						<li><a href="#">견적</a></li>
						<li><a href="#">심사</a></li>
						<li><a href="#">계약</a></li>	
						<li></li>			
					</ul>
				</div>
				<div class="drawer-list">
					<h5><a href=""><i class="icon pannel04" style="background-color:#E5F8D4;"></i><span>기획전</span></a></h5>
				</div>
				<div class="drawer-list">
					<h5><a href=""><i class="icon pannel05" style="background-color:#CFF7EB;"></i><span>뭉치면 특가</span></a></h5>
				</div>
				<div class="drawer-list">
					<h5><i class="icon pannel06" style="background-color:#FFE8E2;"></i><span>혜택 및 이벤트</span></h5>
					<ul>
						<li><a href="#">진행중 이벤트</a></li>
						<li><a href="#">지난 이벤트</a></li>	
						<li><a href="#">제휴카드 혜택</a></li>	
						<li><a href="#">당첨자 발표</a></li>			
					</ul>
				</div>
				<div class="drawer-list">
					<h5><i class="icon pannel07" style="background-color:#E8E2FF;"></i><span>고객센터</span></h5>
					<ul>
						<li><a href="#">FAQ</a></li>
						<li><a href="#">공지사항</a></li>	
						<li><a href="#">일반문의</a></li>	
						<li><a href="#">전문상담신청</a></li>			
					</ul>
				</div>
			</div>
			<!--로그아웃버튼 영역-->
			<div class="drawer-bottom">
				<button type="button">로그아웃<i class="icon goVs"></i></button>
			</div>
			<!--//로그아웃버튼 영역-->

		</div>

	</div>
	<!--//drawer 컴포넌트-->

        <!--fixedBottom 컴포넌트-->
        <div class="fixedBottom">
			<div class="fixedBottom_in">
				<div class="left">
					<button type="button"><i class="icon fixedRight001"></i><span>홈</span></button>
					<button type="button"><i class="icon fixedRight04"></i><span>상담신청</span></button>
				</div>
				<div class="center">
					<button type="button" class="btn btn-fixedRight03"><i class="icon fixedRight03"></i><span>견적</span></button>
				</div>
				<div class="right">
					<button type="button"><i class="icon fixedRight004"></i><span>보관함</span></button>
					<button type="button"><i class="icon fixedRight05"></i><span>마이페이지</span></button>
				</div>
			</div>
		</div>
        <!--//fixedBottom 컴포넌트-->
        <!--fixedRight 컴포넌트-->
        <div class="fixedRight">
			<button type="button" class="btn btn-goWrite">글쓰기</button>
			<!--
			<button type="button" class="btn btn-goTalk">톡톡문의</button>-->
            <button type="button" class="btn btn-goTop">탑으로</button>
        </div>
        <!--//fixedRight 컴포넌트-->
    `;

    $(".footer").html(footer);
	$(".footer .footer").unwrap();
	$(".footer").remove();

});