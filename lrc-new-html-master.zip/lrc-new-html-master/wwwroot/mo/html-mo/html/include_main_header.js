$(function(){


    var header = `
        <!--header 컴포넌트-->
        <header class="header main">
		<div class="header-top">
			<h1>
				<a href="#none">
					<img src="../../../resources-mo/images/common/logo-header.png" alt="신차장 다이렉트"/>
				</a>
			</h1>
			<button type="button" class="btn-drawer" data-target="drawer" data-on="true" data-sort="none"><i class="icon draw">메뉴열기</i></button>
		</div>
		<nav class="header-nav">
			<a href="#" class="active">홈</a>
			<a href="#">빠른출고</a>
			<a href="#">프로모션<span class="new">new</span></a>
			<a href="#">특가모아보기</a>
			<a href="#">이벤트</a>
			<a href="#">고객후기</a>
			<a href="#">신차장TV</a>
		</nav>
	</header>
    `;

    

    $(".header").html(header);
    $(".header .header").unwrap();


});